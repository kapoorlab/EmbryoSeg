# EmbryoSeg
Segmentation tool for multiple touching mouse embryo cells using SmartSeeds
